PM KUSUM Solar Pump — SEO V3

Deployment:
1. Extract this ZIP.
2. Deploy/replace the site files on Netlify.
3. Keep the Google verification HTML file at the site root.
4. In Google Search Console, keep the existing sitemap: https://solerpumpinstalla.netlify.app/sitemap.xml
5. Do not repeatedly request indexing; allow Google time to recrawl.

SEO V3 changes:
- Hindi-focused title and meta description.
- Absolute canonical URL.
- Optimized robots directives.
- Open Graph and Twitter metadata.
- WebSite, WebPage and BreadcrumbList structured data.
- Internal anchor navigation for scheme, eligibility, documents, application information and FAQ.
- Clear non-government disclosure and verification guidance.
- Minor accessibility improvement for images.
- Netlify safe security headers without a CSP, so the existing inline JavaScript remains functional.

IMPORTANT SECURITY WARNING:
The existing site contains a client-side admin credential check and browser-visible Supabase configuration. This is NOT a secure production authentication design. Before storing or processing real applicant data, move admin authentication to Supabase Auth/server-side authorization and enforce Row Level Security (RLS) and storage policies. SEO V3 does not fix this security issue.

The site content itself states that this is an independent informational/application demo portal and not an official Government of India website.
